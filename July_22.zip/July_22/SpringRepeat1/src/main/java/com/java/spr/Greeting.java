package com.java.spr;

public interface Greeting {

	String showInfo(String name);
}

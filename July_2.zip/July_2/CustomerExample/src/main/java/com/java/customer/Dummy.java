package com.java.customer;

public class Dummy {

	public static void main(String[] args) {
		System.out.println(OtpGen.genrateOtp());
	}
}

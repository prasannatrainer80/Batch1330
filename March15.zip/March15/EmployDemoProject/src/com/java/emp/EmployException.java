package com.java.emp;

public class EmployException extends Exception {

	public EmployException(String error) {
		super(error);
	}
}

-- Aggregate Functions 

-- sum() : Used to perform sum. operation on the given field(s) 

select sum(sal) from Emp;

-- avg() : Used to perform avg. operation on the given field(s) 

select avg(sal) from Emp;

-- max()  used to display max. operation on the given field(s)

select max(sal) from Emp;

-- min() Used to display min. operation on the given field(s) 

-- count(*) : Dispalys total  no.of records of the table

select count(*) from emp;

select min(sal) from Emp;
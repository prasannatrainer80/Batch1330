package com.java.junit;

public class App {

  public static void main(String[] args) {
	  Employ empnew = new Employ(1, "Chandra", "Male", "Java", 
				"Developer", 98823);
	  System.out.println(empnew);
    System.out.println("Hello World!");
  }

}

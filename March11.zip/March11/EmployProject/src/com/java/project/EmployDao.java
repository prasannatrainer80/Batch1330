package com.java.project;

import java.util.List;

public interface EmployDao {

	List<Employ> showEmployDao();
	String addEmployDao(Employ employ);
}

use sonixpractice;

create table Users
(
    userName varchar(30) Primary Key,
    passCode varchar(100)
);


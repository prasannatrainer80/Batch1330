package com.java.spr;

public interface NameDao {

	String show();
}
